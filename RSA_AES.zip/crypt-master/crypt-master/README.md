# A C++ Library of encryption, decryption, encode, hash, and message digital signatures.

The same functional and fully compatible dlang project:
https://github.com/shove70/crypto

For more examples, see dlang project, Thanks.

! This project has been included in the shove.c project, and subsequent updates will only be included in the shove.c project:
https://github.com/shove70/shove.c
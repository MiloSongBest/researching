# TrueLicenseDemo

#### 项目介绍
TrueLicenseDemo是TrueLicense的使用案例

#### 安装教程

1. 下载下来项目，导入到idea即可，如果使用的ecplise，自行解决转换问题

#### 使用说明

1. LicenseCreate为创建lincense.lic的项目
2. LicenseVerify为修校验lincense.lic的项目
3. LicenseVerify中有mac地址获取类ListNets.java
4. 每个项目下都有test文件供用户测试使用

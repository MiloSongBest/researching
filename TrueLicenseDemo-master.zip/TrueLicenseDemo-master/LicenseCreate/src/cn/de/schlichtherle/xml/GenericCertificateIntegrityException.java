package cn.de.schlichtherle.xml;

import java.security.GeneralSecurityException;

public class GenericCertificateIntegrityException
        extends GeneralSecurityException {
}

package cn.de.schlichtherle.xml;

abstract interface XMLConstants {
    public static final String XML_CHARSET = "UTF-8";
    public static final int DEFAULT_BUFSIZE = 10240;
}

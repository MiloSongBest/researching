package cn.de.schlichtherle.xml;

public class GenericCertificateNotLockedException
  extends IllegalStateException
{}

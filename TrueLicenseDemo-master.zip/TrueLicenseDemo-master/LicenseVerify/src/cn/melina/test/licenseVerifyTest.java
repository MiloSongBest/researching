package cn.melina.test;

import cn.melina.license.VerifyLicense;

public class licenseVerifyTest {
    public static void main(String[] args) {
        VerifyLicense vLicense = new VerifyLicense();
        vLicense.setParam("param.properties");
        vLicense.verify();
    }
}

package cn.melina.license;

import cn.de.schlichtherle.license.LicenseManager;
import cn.de.schlichtherle.license.LicenseParam;

/**
 * LicenseManager
 */
public class LicenseManagerHolder {

    private static LicenseManager licenseManager;

    public static synchronized LicenseManager getLicenseManager(LicenseParam licenseParams) {
        if (licenseManager == null) {
            licenseManager = new LicenseManager(licenseParams);
        }
        return licenseManager;
    }
}
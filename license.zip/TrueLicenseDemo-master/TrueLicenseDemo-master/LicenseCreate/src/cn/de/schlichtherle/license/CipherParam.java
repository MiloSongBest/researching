package cn.de.schlichtherle.license;

public abstract interface CipherParam {
    public abstract String getKeyPwd();
}

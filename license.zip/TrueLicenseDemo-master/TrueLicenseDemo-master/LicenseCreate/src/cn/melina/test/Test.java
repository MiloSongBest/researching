package cn.melina.test;

import cn.melina.license.CreateLicense;

public class Test {

    public static void main(String[] args) throws Exception {
        CreateLicense createLicense = new CreateLicense();
        createLicense.setParam("param.properties");
        createLicense.create();
    }

}

package com.sixj.license;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author sixiaojie
 * @date 2021-01-27-09:55
 */
@Configuration
@ComponentScan(value = "com.sixj.license")
public class LicenseVerifyAutoConfiguration {

}
